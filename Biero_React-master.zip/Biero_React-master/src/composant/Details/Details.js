import './Details.css';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router';


export default function Details({estConnecte, courriel}){

    const {api_url} = "http://127.0.0.1:8000/webservice/php/";
    const {id} = useParams();

    const [produit, setProduit] = useState([]);
    const [commentaires, setCommentaires] = useState([]);
    const [note, setNote] = useState([]);

    const [inputValue, setInputValues] = useState([]);

    useEffect(()=>{
        fetch('http://127.0.0.1:8000/webservice/php/biere/'+id)
        .then(data=>data.json())
        .then(data=>{
            console.log(data);
            setProduit(data.data);
            });

        fetch('http://127.0.0.1:8000/webservice/php/biere/'+id+'/commentaire')
        .then(data=>data.json())
        .then(data=>{
            console.log(data.data);
            setCommentaires(data.data);

        });

        fetch('http://127.0.0.1:8000/webservice/php/biere/'+id+'/note')
        .then(data=>data.json())
        .then(data=>{
            //console.log(data.data.note);
            setNote(data.data);

        });

    }, []);


    const handleChange = (event)=>{
        setInputValues({...inputValue, [event.target.name]: event.target.value});
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        // let entete = new Headers();
        // entete.append("Content-Type", "application/json");
        // entete.append("Authorization", "Basic " + btoa("biero:biero"));

        console.log(inputValue);
        fetch('http://127.0.0.1:8000/webservice/php/biere/'+id+"/commentaire", {
            method:"PUT",
            body:JSON.stringify(inputValue),
            headers : {"Content-Type": "application/json"}
        })
            .then(response=>response.json())
            .then(data=>{
                console.log(data);
                //fctRappel(data)
            })
    };

    let message='';
    let formulaire="";
    if(estConnecte){
        message = <p>Connecté en tant que : {courriel} </p>
        formulaire = <form onSubmit={handleSubmit}>
                        <h3>Ajouter un commentaire : </h3>
                        <label for="commentaire">Commentaire</label>
                        <textarea name='commentaire' onChange={handleChange}></textarea>
                        <button type='submit'>Ajouter</button>
                    </form>
    }

    // setCommentaires(evt){
    //     console.log(evt.target.value);
    //     let commentaire = evt.target.value;
    //     let valide;
    //     if(commentaire !=""){
    //         valide = true;
    //     }else{
    //         valide =false;
    //     }

    //     this.setState({
    //         commentaireValide : valide,
    //         commentaire : commentaire
    //     })
    // }

    return (

        <>
        <section>
        
        <div>
            <img src='https://picsum.photos/450/300' alt='biere_image'></img>
        </div>
            <h1>Details d'un biere</h1>
            <p><strong>Nom : </strong>{produit.nom}</p>
            <p><strong>Description : </strong>{produit.description}</p>
        </section>

        <section>
        <h3>Commentaires</h3>
            {commentaires.map(unCommentaire=>
                <p>{unCommentaire.commentaire}</p>
                
            )}
        </section>

        <section>
            <h3>Note</h3>
            <p>{note.note}</p>
        </section>
        {message}
        {formulaire}

        </>

    );
}