# Installation des dépendances 
Après le `git clone`, faire `npm install` pour installer les dépendances

### Pour lancer le serveur de développement
`npm start`

